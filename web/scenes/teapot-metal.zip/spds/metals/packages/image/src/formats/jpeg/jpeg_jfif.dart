part of image;

class JpegJfif {
  int majorVersion;
  int minorVersion;
  int densityUnits;
  int xDensity;
  int yDensity;
  int thumbWidth;
  int thumbHeight;
  InputBuffer thumbData;
}
