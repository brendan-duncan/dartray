part of image;

class PsdImageResource {
  int id;
  String name;
  InputBuffer data;

  PsdImageResource(this.id, this.name, this.data);
}
