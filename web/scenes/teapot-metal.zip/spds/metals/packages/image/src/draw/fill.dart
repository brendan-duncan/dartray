part of image;

/**
 * Set all of the pixels of an [image] to the given [color].
 */
Image fill(Image image, int color) {
  return image.fill(color);
}
