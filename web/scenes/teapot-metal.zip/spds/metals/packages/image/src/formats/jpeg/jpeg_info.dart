part of image;

class JpegInfo extends DecodeInfo {
  /// The number of frames that can be decoded.
  int get numFrames => 1;
}
